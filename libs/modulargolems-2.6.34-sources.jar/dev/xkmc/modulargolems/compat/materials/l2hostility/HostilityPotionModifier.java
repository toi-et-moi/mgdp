package dev.xkmc.modulargolems.compat.materials.l2hostility;

import dev.xkmc.modulargolems.content.core.StatFilterType;
import dev.xkmc.modulargolems.content.item.upgrade.IUpgradeItem;
import dev.xkmc.modulargolems.content.item.upgrade.UpgradeItem;
import dev.xkmc.modulargolems.content.modifier.base.GolemModifier;
import dev.xkmc.modulargolems.init.data.MGTagGen;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class HostilityPotionModifier extends GolemModifier {

	public HostilityPotionModifier(StatFilterType type, int maxLevel) {
		super(type, maxLevel);
	}

	@Override
	public int addSlot(List<IUpgradeItem> upgrades, int lv) {
		Set<IUpgradeItem> set = new HashSet<>();
		for (var e : upgrades) {
			if (e.asItem().getDefaultInstance().is(MGTagGen.POTION_UPGRADES)) {
				set.add(e);
			}
		}
		return set.size();
	}
}
