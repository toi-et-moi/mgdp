package dev.xkmc.modulargolems.content.entity.humanoid;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.xkmc.modulargolems.compat.curio.CuriosClientRegistry;
import dev.xkmc.modulargolems.content.entity.common.AbstractGolemRenderer;
import dev.xkmc.modulargolems.content.entity.common.GolemBannerLayer;
import dev.xkmc.modulargolems.content.entity.humanoid.skin.ClientSkinDispatch;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.layers.CustomHeadLayer;
import net.minecraft.client.renderer.entity.layers.ElytraLayer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraftforge.fml.ModList;
import org.jetbrains.annotations.Nullable;

public class HumanoidGolemRenderer extends AbstractGolemRenderer<HumanoidGolemEntity, HumanoidGolemPartType, HumanoidGolemModel> {

	protected static void transform(PoseStack stack, ItemDisplayContext transform, @Nullable HumanoidGolemPartType part) {
		switch (transform) {
			case GUI:
			case FIRST_PERSON_LEFT_HAND:
			case FIRST_PERSON_RIGHT_HAND:
				break;
			case THIRD_PERSON_LEFT_HAND:
			case THIRD_PERSON_RIGHT_HAND: {
				stack.translate(0.25, 0.4, 0.5);
				float size = 0.625f;
				stack.scale(size, size, size);
				break;
			}
			case GROUND: {
				stack.translate(0.25, 0, 0.5);
				float size = 0.625f;
				stack.scale(size, size, size);
				break;
			}
			case NONE:
			case HEAD:
			case FIXED: {
				stack.translate(0.5, 0.5, 0.5);
				float size = 0.5f;
				stack.scale(size, -size, size);
				stack.translate(0, -0.5, 0);
				return;
			}
			default:
				stack.translate(0, 0, 0.5);
				break;
		}
		stack.mulPose(Axis.ZP.rotationDegrees(135));
		stack.mulPose(Axis.YP.rotationDegrees(-155));
		if (part == null) {
			float size = 0.45f;
			stack.scale(size, size, size);
			stack.translate(0, -2, 0);
		} else if (part == HumanoidGolemPartType.BODY) {
			float size = 0.65f;
			stack.scale(size, size, size);
			stack.translate(0, -1.2, 0);
		} else if (part == HumanoidGolemPartType.LEGS) {
			float size = 0.8f;
			stack.scale(size, size, size);
			stack.translate(0, -2, 0);
		} else if (part == HumanoidGolemPartType.ARMS) {
			float size = 0.6f;
			stack.scale(size, size, size);
			stack.translate(0, -1.5, 0);
		}
	}

	public HumanoidGolemRenderer(EntityRendererProvider.Context ctx) {
		this(ctx, false);
	}

	public HumanoidGolemRenderer(EntityRendererProvider.Context ctx, boolean slim) {
		this(ctx, ctx.bakeLayer(slim ? ModelLayers.PLAYER_SLIM : ModelLayers.PLAYER), slim);
	}

	public HumanoidGolemRenderer(EntityRendererProvider.Context ctx, ModelPart body, boolean slim) {
		this(ctx, body, slim,
				ctx.bakeLayer(slim ? ModelLayers.PLAYER_SLIM_INNER_ARMOR : ModelLayers.PLAYER_INNER_ARMOR),
				ctx.bakeLayer(slim ? ModelLayers.PLAYER_SLIM_OUTER_ARMOR : ModelLayers.PLAYER_OUTER_ARMOR));
	}

	public HumanoidGolemRenderer(EntityRendererProvider.Context ctx, ModelPart body, boolean slim, ModelPart innerArmor, ModelPart outerArmor) {
		super(ctx, new HumanoidGolemModel(body, slim), 0.5f, HumanoidGolemPartType::values);
		this.addLayer(new HumanoidArmorLayer<>(this,
				new HumanoidModel<>(innerArmor),
				new HumanoidModel<>(outerArmor),
				ctx.getModelManager()));
		this.addLayer(new CustomHeadLayer<>(this, ctx.getModelSet(),
				1, 1, 1, ctx.getItemInHandRenderer()));
		this.addLayer(new ElytraLayer<>(this, ctx.getModelSet()));
		this.addLayer(new LayerWrapper<>(this,
				new ItemInGolemHandLayer<>(this, ctx.getItemInHandRenderer())));
		this.addLayer(new GolemBannerLayer<>(this, ctx.getItemInHandRenderer()));
		if (ModList.get().isLoaded("curios")) {
			CuriosClientRegistry.createLayer(this);
		}
	}

	@Override
	public void render(HumanoidGolemEntity entity, float f1, float f2, PoseStack stack, MultiBufferSource source, int i) {
		var camera = Minecraft.getInstance().getCameraEntity();
		if (Minecraft.getInstance().options.getCameraType() == CameraType.FIRST_PERSON &&
				camera != null && camera.getVehicle() != null &&
				entity.getVehicle() == camera.getVehicle())
			return;
		var profile = ClientSkinDispatch.get(entity);
		if (profile != null) {
			profile.render(entity, f1, f2, stack, source, i);
			return;
		}
		renderImpl(entity, f1, f2, stack, source, i);
	}

	public void renderImpl(HumanoidGolemEntity entity, float f1, float f2, PoseStack stack, MultiBufferSource source, int i) {
		super.render(entity, f1, f2, stack, source, i);
	}

	public static final ThreadLocal<HumanoidGolemModel> MODEL_DELEGATE = new ThreadLocal<>();

	@Override
	public HumanoidGolemModel getModel() {
		var override = MODEL_DELEGATE.get();
		if (override != null) return override;
		return super.getModel();
	}
}
